class Song {
    String title;
    int lenInSeconds;  // duration of the song

    Song (String title, Integer lenInSeconds) {
        this.title = title;
        this.lenInSeconds = lenInSeconds;
    }
}
